import os
import json
import platform
from argparse import ArgumentParser
from zipfile import ZipFile

current_dir = ""

parser = ArgumentParser()
parser.add_argument("pc_name", type=str)
parser.add_argument("zip_name", type=str)
parser.add_argument("log_name", type=str)
args = parser.parse_args()

zip_path = "c:/users/stintav/desktop/conf1/" + args.zip_name
log_path = "c:/users/stintav/desktop/conf1/" + args.log_name

def append2json(action: str):
    with open(log_path, "r") as file:
        data = json.load(file)
    data["actions"].append(action)
    with open(log_path, "w") as file:
        if not data["actions"]:
            data["actions"] = []
        json.dump(data, file, indent=4)

with ZipFile(zip_path, 'r') as myzip:
    while True:
        command = input("windows@" + args.pc_name + ":~\\" + current_dir + "$ ")
        if command == "ls":
            append2json(command)
            contents = [name[len(current_dir):].split("/")[0] for name in myzip.namelist() if name.startswith(current_dir) and name != current_dir]
            for item in sorted(set(contents)):
                print(item)
        elif command.startswith("cd"):
            append2json(command)
            target_dir = command.split(maxsplit=1)[1]
            if target_dir == "..":
                current_dir = "/".join(current_dir.strip('/').split('/')[:-1])
                if current_dir:
                    current_dir += "/"
            else:
                target_path = current_dir + target_dir + "/"
                if any(name.startswith(target_path) for name in myzip.namelist()):
                    current_dir = target_path
                else:
                    print("cd: no such directory")
        elif command == "pwd":
            append2json(command)
            print(os.getcwd() + "/" + current_dir)
        elif command == "uname":
            append2json(command)
            print(platform.system())
        elif command.startswith("cat"):
            append2json(command)
            file_path = current_dir + command.split(maxsplit=1)[1]
            if file_path in myzip.namelist():
                with myzip.open(file_path) as file:
                    print(file.read().decode('utf-8'))
            else:
                print("cat: no such file")
        elif command == "exit":
            append2json(command)
            break
        else:
            print("command not found: " + command)

