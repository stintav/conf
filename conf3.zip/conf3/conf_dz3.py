import re
import sys
import argparse
from xml.etree.ElementTree import Element, SubElement, tostring, ElementTree
from xml.dom import minidom

def parse_config(input_text):
    input_text = re.sub(r'REM.*', '', input_text)

    lines = input_text.splitlines()
    lines = [line.strip() for line in lines if line.strip()]

    result = {"dictionary": {}}
    constants = {}
    current_dict = None

    for line in lines:
        if line.startswith("begin"):
            if current_dict is not None:
                raise ValueError("Вложенные блоки begin не поддерживаются.")
            current_dict = result["dictionary"]
        elif line.startswith("end"):
            if current_dict is None:
                raise ValueError("end без begin.")
            current_dict = None
        elif ":=" in line:
            key, value = map(str.strip, line.split(":=", 1))
            resolved_value = resolve_value(value, constants)
            if current_dict is not None:
                current_dict[key] = resolved_value
            else:
                constants[key] = resolved_value
        else:
            raise ValueError(f"Некорректная строка: {line}")
    return result

def resolve_value(value, constants):
    if value.isdigit():
        return int(value)
    elif value.startswith("@(") and value.endswith(");"):
        const_name = value[2:-2].strip()
        if const_name in constants:
            return constants[const_name]
        else:
            raise ValueError(f"Неизвестная константа: {const_name}")
    return value

def convert_to_xml(parsed_data):
    root = Element("configuration")
    if "dictionary" in parsed_data:
        dict_element = SubElement(root, "dictionary")
        for key, value in parsed_data["dictionary"].items():
            item = SubElement(dict_element, "entry", name=key)
            item.text = str(value)
    return root

def save_xml_to_file(xml_element, file_path):
    rough_string = tostring(xml_element, 'utf-8')
    reparsed = minidom.parseString(rough_string)
    formatted_xml = reparsed.toprettyxml(indent="  ")
    formatted_xml_without_declaration = '\n'.join(formatted_xml.split('\n')[1:])
    with open(file_path, "w", encoding="utf-8") as file:
        file.write(formatted_xml_without_declaration)

parser = argparse.ArgumentParser(description="Конвертер учебного конфигурационного языка в XML.")
parser.add_argument("file_name", type=str, help="Путь для сохранения XML-файла.")
args = parser.parse_args()

print("Введите текст конфигурации (завершите ввод Ctrl+Z на новой строке и нажмите Enter):")
input_text = sys.stdin.read()

parsed_data = parse_config(input_text)
xml_data = convert_to_xml(parsed_data)
save_xml_to_file(xml_data, args.file_name)
file_name = "c:/users/stintav/desktop/py/conf3/" + args.file_name
print(f"Конфигурация успешно сохранена в {file_name}")

