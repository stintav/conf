import argparse 
from configparser import ConfigParser
from tkinter import PhotoImage, Tk, Label
from graphviz import Digraph
import xml.etree.ElementTree as ET

def process_node(graph, parent, node, current_depth, max_depth):
    if current_depth > max_depth:
        return
    for child in node:
        graph.edge(parent, child.tag)
        process_node(graph, child.tag, child, current_depth + 1, max_depth)

parser = argparse.ArgumentParser()
parser.add_argument("config_name", type=str)
args = parser.parse_args()

config = ConfigParser()
config.read("c:/users/stintav/desktop/py/conf2/" + args.config_name)
pkg_name = config['content']['package_name']
max_depth = int(config['content']['max_depth'])

tree = ET.parse(pkg_name)
root = tree.getroot()

graph = Digraph(comment="Dependencies Graph")
graph.node(root.tag, root.tag)

process_node(graph, root.tag, root, current_depth=1, max_depth=max_depth)
image_name = "graph_output"
graph.render(image_name, format="png", cleanup=True)
print("Граф успешно создан и сохранён как " + image_name + ".png")

window = Tk()
window.title("graph")
img = PhotoImage(file=image_name + ".png")
label = Label(window, image=img)
label.pack()
window.mainloop()

#cd desktop\py\conf2

